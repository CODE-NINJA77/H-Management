import OrderingPage from './pages/OrderingPage';

function App() {
  return <OrderingPage />;
}

export default App;
