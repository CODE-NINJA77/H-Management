/*
  # Create Menu Items Table

  1. New Tables
    - `menu_items`
      - `id` (uuid, primary key)
      - `name` (text, item name)
      - `price` (integer, price in INR)
      - `description` (text, item description)
      - `category` (text, food category)
      - `image_url` (text, optional image URL)
      - `available` (boolean, availability status)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `menu_items` table
    - Add policy for public SELECT (menu is public)
*/

CREATE TABLE IF NOT EXISTS menu_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  price integer NOT NULL,
  description text,
  category text NOT NULL,
  image_url text,
  available boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE menu_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Menu items are publicly readable"
  ON menu_items
  FOR SELECT
  TO public
  USING (true);

INSERT INTO menu_items (name, price, description, category, available) VALUES
  ('Masala Dosa', 60, 'Crispy crepe filled with spiced potato', 'South Indian', true),
  ('Idly', 30, 'Steamed rice cake served with sambar and chutney', 'South Indian', true),
  ('Vada', 25, 'Crispy fried donut-shaped fritter', 'South Indian', true),
  ('Coffee', 20, 'Hot brewed filter coffee', 'Beverages', true),
  ('Uttapam', 50, 'Thick pancake topped with vegetables', 'South Indian', true),
  ('Sambhar', 40, 'Lentil-based vegetable stew', 'South Indian', true),
  ('Chutney (Coconut)', 15, 'Fresh coconut chutney', 'Accompaniments', true),
  ('Chai', 15, 'Hot spiced tea', 'Beverages', true),
  ('Medu Vada', 35, 'Soft fried lentil donuts', 'South Indian', true),
  ('Puri Bhaji', 45, 'Fried bread with potato curry', 'North Indian', true);
